import './App.css';
import GuessNumber from './GuessNumber';

function App() {
  return (
    <div className="App">
      <GuessNumber/>
    </div>
  );
}

export default App;
