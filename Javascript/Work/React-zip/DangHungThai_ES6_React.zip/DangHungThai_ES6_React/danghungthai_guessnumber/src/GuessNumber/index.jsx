import React, { Component } from 'react';
import './style.css';
class GuessNumber extends Component {
    arrayNumber = [];
    soLanChon = 0;

    guessNumber = Math.round(Math.random() * 1000);
    renderResult = () => {
        console.log(this.arrayNumber);
        return this.arrayNumber.map((number, index) => {
            return (
                <tr>
                    <td>Lần {index + 1}: {number}</td>
                </tr>
            )
        });
    }
    checkValue = (playerChoice) => {
        if (playerChoice < this.guessNumber) {
            // soLanChon++;
            return <button className="btn btn-danger mt-3">Số nhập phải lớn hớn {playerChoice}</button>
        } else if (playerChoice > this.guessNumber) {
            // soLanChon++;
            return <button className="btn btn-danger mt-3">Số nhập phải nhỏ hớn {playerChoice}</button>
        } else if (playerChoice == this.guessNumber) {
            // soLanChon++;
            return <button style = {{fontSize: "30px"}}className="btn btn-info mt-3">Chúc mừng bạn đã chọn đúng đáp án là {this.guessNumber}
            <br/>
                    <button className="btn btn-info mt-2">Số Lần Chọn là: {this.soLanChon}</button>
                    <br/>
                    <button type="button" className="btn btn-warning" data-toggle="modal" data-target="#modelId">
                        Xem Lịch Sử Chọn
                    </button>
            
            </button>
        }
        //  else if(playerChoice > 1000 || playerChoice < 0){
        //     soLanChon++;
        //     return <button className="btn btn-danger mt-3">Số nhập không hợp lệ</button>
        // } 
        else {
            // this.soLanChon++;
            return <button className="btn btn-danger mt-3">Số nhập không hợp lệ</button>
        }
    }
    state = {
        value: null,
        
    }

    handleChange = (event) => {
        this.setState({
            value: event.target.value
        });
        this.soLanChon++;
    }
    handleOnSubmit = (event) => {
        this.arrayNumber.push(this.state.value);
        this.checkValue(this.state.value);
        event.preventDefault();
        console.log(this.guessNumber);
        // console.log(this.arrayNumber);
        this.setState({})
    }
    render() {
        return (
            <div className="container-fluid">
                <h1 className="display-4 m-0">Trò Chơi Đoán Chữ</h1>
                <p>Yêu cầu: Dự đoán số máy chọn trong khoảng [0 - 1000]</p>

                <input onBlur={this.handleChange} type="text" placeholder="Nhập số" />
                <div className= "mt-3">
                    <button className="btn btn-success mr-2" onClick={this.handleOnSubmit}>Dự đoán</button>
                </div>
                {this.state.value && this.checkValue(this.state.value)}
                <div> 
                    {/* Modal */}
                    <div className="modal fade" id="modelId" tabIndex={-1} role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">Lịch Sử Chọn</h5>
                                    <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div className="modal-body" style={{ height: "auto" }}>
                                    {this.renderResult()}
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}

export default GuessNumber;