import React, { Component } from "react";

class GheItem extends Component {
  onGetGhe = () => {
    this.props.getGhe(this.props.Ghe);
    
  };
  checkTrangThai = () => {
    switch (this.props.Ghe.TrangThai) {
      case true: {
        return "btn btn-success p-3 mb-2";
      }
      case false: {
        const index = this.props.danhSachGheDangChon.findIndex((item) => {
          return item.Ghe.SoGhe === this.props.Ghe.SoGhe;
        });
        console.log(index);
        if (index !== -1) {
          return "btn btn-danger p-3 mb-2";
        } else {
          return "btn btn-secondary p-3 mb-2";
        }
      }
    }
  };

  render() {
    const { SoGhe, TrangThai } = this.props.Ghe;
    return (
      <button
        className={this.checkTrangThai()}
        onClick={this.onGetGhe}
        disabled={TrangThai}
      >
        {SoGhe}
      </button>
    );
  }
}
export default GheItem;
