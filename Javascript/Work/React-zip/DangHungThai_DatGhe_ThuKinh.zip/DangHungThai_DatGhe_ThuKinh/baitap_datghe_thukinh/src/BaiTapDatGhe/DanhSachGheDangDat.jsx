import React, { Component } from "react";

class DanhSachGheDangDat extends Component {
  renderDanhSachGheDangChon = () => {
    return this.props.danhSachGheDangChon.map((item) => {
      return (
        <p key ={item.SoGhe} className="text-left pl-5">Ghế : {item.Ghe.TenGhe} {item.Ghe.Gia}$ <span className="text-danger">[Huỷ]</span>
        </p>
      );
    });
  };
  render() {
    return (
      <div>
        <h1 className="text-warning">
          Danh sách ghế đã đặt ({this.props.quantity})
        </h1>
        {this.renderDanhSachGheDangChon()}
      </div>
    );
  }
}

export default DanhSachGheDangDat;
