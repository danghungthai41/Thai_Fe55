import React, { Component } from 'react';
import GheItem from './GheItem';

class DanhSachGhe extends Component {
    renderGheItem = () => {
        return this.props.Ghe.map((item, index) => {
            return <div className="col-3 p-0">
                     <GheItem Ghe={item} key={index} getGhe = {this.props.getGhe} danhSachGheDangChon = {this.props.danhSachGheDangChon} />
                  </div>

        });
    };
    render() {
        return (
            <div>
                <button className="btn btn-secondary px-5 w-75 p-3 mb-4">Tài Xế</button>
                <div className="row">
                    {this.renderGheItem()}
                </div>
            </div>
        );
    }
}

export default DanhSachGhe;