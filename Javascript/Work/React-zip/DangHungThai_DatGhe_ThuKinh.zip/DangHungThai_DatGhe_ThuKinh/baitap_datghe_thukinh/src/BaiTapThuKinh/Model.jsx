import React, { Component } from "react";
import Character from "../assets/glassesImage/model.jpg";
export default class Model extends Component {
  render() {
    const { url, name, desc } = this.props.glassItem;
    return (
      <div className="card">
        <img src={Character} style={{ width: 150, marginLeft: "39%" }} alt="Model" />
        <div className="card-body">
          {url && (
            <img
              style={{ width: "80px", position: "absolute", left: "44%", top: 45 }}
              src={url}
              alt="img"
            />
          )}
          <h3 className="display-5">{name}</h3>
          <p>{desc}</p>
        </div>
      </div>
    );
  }
}
