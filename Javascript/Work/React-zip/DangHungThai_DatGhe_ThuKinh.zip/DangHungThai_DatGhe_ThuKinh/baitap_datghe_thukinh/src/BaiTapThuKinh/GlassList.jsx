import React, { Component } from "react";

export default class GlassList extends Component {
  renderGlassItem = () => {
    return this.props.arrProduct.map((item) => {
      return (
        <img
          key={item.id}
          onClick={this.onViewGlassItem(item)}
          style={{ width: "80px" }}
          src={item.url}
          alt="Glass"
          key={item.id}
        />
      );
    });
  };

  onViewGlassItem = (index) => () => this.props.getGlassItem(index);

  render() {
    return (
      <div>
        <h1 className="display-5">Nhấn Để Thử Kính</h1>
        {this.renderGlassItem()}
      </div>
    );
  }
}
