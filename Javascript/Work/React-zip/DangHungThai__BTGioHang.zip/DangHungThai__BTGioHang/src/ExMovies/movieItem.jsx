import React, { Component } from 'react'

export default class MovieItem extends Component {
    render() {
        //destructuring 
        const {hinhAnh, tenPhim, moTa} = this.props.movie;
        // console.log(this.props.movie);
        return (
            <div className="card">
            <img class="w-100" src={hinhAnh} alt="movie items" />
            <div className="card-body">
                <h3>{tenPhim}</h3>
                <p>{moTa}</p>
            </div>
        </div>
        );
    };
}
