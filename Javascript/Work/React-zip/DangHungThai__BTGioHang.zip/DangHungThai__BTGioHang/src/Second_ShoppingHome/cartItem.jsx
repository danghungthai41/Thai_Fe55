import React, { Component } from 'react';

class CartItem extends Component {
    buttonOn = () => {
        this.props.buttonOn(this.props.cart.quantity++);
    }
    buttonDown = () => {
        if (this.props.cart.quantity > 1)
            this.props.buttonDown(this.props.cart.quantity--);
        else
            this.props.cart.quantity = 1;
    }
    deleteItem = () => {
        this.props.removeCartItem(this.props.cart);
    }

    render() {
        const { id, name, img, price } = this.props.cart.product;
        const { quantity } = this.props.cart;
        const totalPrice = () => {
            return quantity * price;
        }

        return (

            <tr>
                <td>{id}</td>
                <td><img src={img} alt={img} style={{ width: 80 }} /></td>
                <td>{name}</td>
                <td>
                    <button className="btn btn-info" onClick={this.buttonOn}>+</button>
                    {quantity}
                    <button className="btn btn-info" onClick={this.buttonDown}>-</button>
                </td>
                <td>{price.toLocaleString()}</td>
                <td>{totalPrice().toLocaleString()}
                </td>
                <td><button type="button" className="btn btn-danger ml-2" onClick={this.deleteItem}>Xoá</button>
                </td>
            </tr>
        );
    }
}

export default CartItem;