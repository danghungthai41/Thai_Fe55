import React, { Component } from 'react';
// import Detail from './detail';

class ProductItem extends Component {
    onViewProduct = () => {
        this.props.getProduct(this.props.products);
    }
    onAddToCart = () => {
        this.props.addToCart(this.props.products);
    }
    render() {
        const {img, name} = this.props.products;
        return (
                 <div className="card">
                    <img style = {{height: 250}} src= {img} alt="Product_1"/>
                    <div className="card-body">
                        <p className="text-center lead font-weight-bold">{name}</p>
                        <button className="btn btn-success" onClick = {this.onViewProduct}>Xem chi tiết</button>
                        <button className="btn btn-info" onClick = {this.onAddToCart}>Thêm giỏ hàng</button>
                    </div>
                </div>
        );
    }
}

export default ProductItem;