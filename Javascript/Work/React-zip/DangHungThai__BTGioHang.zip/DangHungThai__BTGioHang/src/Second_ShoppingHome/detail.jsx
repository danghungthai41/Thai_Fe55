import React, { Component } from 'react';

class Detail extends Component {
render() {
    const {name, img, screen, backCamera, frontCamera, price } = this.props.product || {};

    return (
        <div className="container">
            <div className="row">
                <div className="col-4">
                    <h1>{name}</h1>
                    <img src={img} alt="Product_1" style = {{height :200}} />
                </div>

                <div className="col-8">
                    <h1>Thông Số Kỹ Thuật</h1>

                    <table className="table">
                        <tr>
                            <td>Màn Hình</td>
                            <td>{screen}</td>
                        </tr>

                        <tr>
                            <td>Camera Trước</td>
                            <td>{backCamera}</td>
                        </tr>
                        <tr>
                            <td>Camera Sau</td>
                            <td>{frontCamera}</td>
                        </tr>
                        <tr>
                            <td>Giá Sản Phẩm</td>
                            <td>{price}</td>
                        </tr>


                    </table>
                </div>


            </div>
        </div>
    );
}
}

export default Detail;