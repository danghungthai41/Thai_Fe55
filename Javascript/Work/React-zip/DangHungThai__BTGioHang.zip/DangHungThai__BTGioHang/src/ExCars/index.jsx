import React, { Component } from 'react'
import IconRed from '../assets/img/icon-red.jpg';
import IconBlack from '../assets/img/icon-black.jpg';
import IconSilver from '../assets/img/icon-silver.jpg';
import IconSteel from '../assets/img/icon-steel.jpg';
import RedCar from "../assets/img/red-car.jpg";
import SilverCar from "../assets/img/silver-car.jpg";
import SteelCar from "../assets/img/steel-car.jpg";
import BlackCar from "../assets/img/black-car.jpg";




export default class ExerciseChangeColorCars extends Component {
    state = {
        carImage: RedCar,
    };
    //Create 1 function onChangeColor (img){}
    onChangeColor = (img) => () => {
        this.setState({
            carImage: img,
        },
            () => {
                console.log(this.state.carImage);
            }
        );
    };

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-9">
                        <img src={this.state.carImage} alt="" className="w-100" alt="Cars" />
                    </div>
                    <div className="col-3">
                        <img onClick={this.onChangeColor(RedCar)} src={IconRed} alt="" className="w-25 d-block mb-3" />
                        <img onClick={this.onChangeColor(BlackCar)} src={IconBlack} alt="" className="w-25 d-block " />
                        <img onClick={this.onChangeColor(SilverCar)} src={IconSilver} alt="" className="w-25 d-block mb-3" />
                        <img onClick={this.onChangeColor(SteelCar)} src={IconSteel} alt="" className="w-25 d-block mb-3" />
                    </div>
                </div>
            </div>
        )
    }
}
