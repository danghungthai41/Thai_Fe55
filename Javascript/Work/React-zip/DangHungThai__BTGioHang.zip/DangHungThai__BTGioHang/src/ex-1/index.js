import React from 'react';
import Header from './header';
import Content from './content';
import Sidebar from './sidebar';
import Footer from './footer'
import './index.css';
class Index extends React.Component {
    render() {
        return (
            <div>
                <Header/>
                <div className = "d-flex">
                    <Content/>
                    <Sidebar/>
                </div>

                <Footer/>
            </div>
        )
    }
}
export default Index;