import React from 'react';
import './content.css';
class Content extends React.Component {
    render() {
        return (
            <div className ="content">
                <h1>Content</h1>
            </div>
        )
    }
}
export default Content;