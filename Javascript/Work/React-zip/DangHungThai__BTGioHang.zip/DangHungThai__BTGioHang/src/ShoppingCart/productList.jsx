import React, { Component } from 'react';
import ProductItem from './productItem';

class ProductList extends Component {
    renderProducts = () => {
        return this.props.products.map((item) => {
            return (<div className="col-3" key = {item.id}>
                <ProductItem product = {item} getProduct = {this.props.getProduct} addToCart = {this.props.addToCart}/>
            </div>
            );
        });
    };
    render() {
        return (
            <div className="container">
                <h1 className="display-4 text-center text-dark">Danh Sách Sản Phẩm</h1>
                <div className="row">
                {this.renderProducts()}
                </div>
            </div>
        );
    };
}

export default ProductList;