import React, { Component } from 'react';

class ProductItem extends Component {
    onViewDetail = () => {
        this.props.getProduct(this.props.product);
    };
    onAddToCart = () => {
        this.props.addToCart(this.props.product);
    }
    render() {
        const { img, name } = this.props.product;
        return (
            <div className="card">
                <img src={img} alt="Product-1" style={{ height: 250 }} />
                <div className="card-body">
                    <p className="lead font-weight-bold">{name}</p>
                    <div className="btn btn-success" onClick={this.onViewDetail}>Xem chi tiết</div>
                    <div className="btn btn-danger" onClick = {this.onAddToCart}>Thêm giỏ hàng</div>
                </div>
            </div>
        );
    }
}

export default ProductItem;