import React, { Component } from 'react';

class CartItem extends Component {
    render() {
        const {id, img, name, price} = this.props.cart.product;
        const {quantity} = this.props.cart;

        return (
            <tr>
                <td>{id}</td>
                <td><img src={img} alt="Product" style = {{width : 100}} /></td>
                <td>{name}</td>
                <td>
                    <button className="btn btn-info">+</button>
                    {quantity}
                    <button className="btn btn-info">-</button>
                </td>
                <td>{price}</td>
                <td>180 ngàn</td>
            </tr>
        );
    }
}

export default CartItem;