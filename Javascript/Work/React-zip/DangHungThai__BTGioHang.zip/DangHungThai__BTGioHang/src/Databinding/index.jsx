import React, { Component } from 'react'

export default class DemoDatabinding extends Component {
    //Hàm bình thường
    fullName = 'Đặng Hùng Thái';
    age = 12;
    state = {
        isOk: true,
    }

    //Hàm bình thường
    showName() {
        alert('Đặng Hùng Thái');
    }
    //Hàm có tham số đầu vào
    //Closure: Hàm a return về hàm B, thì hàm B gọi là closure
    showNameWithParams = (name) => () => alert(name);
    //Hàm có con trỏ this
    showNameWithThis = () => {
        alert (this.fullName);
    }

    //Hàm ẩn hiện
    decideDestination = () =>{
        if(this.state.isOk){
            return <h1>GO TO CYBERSOFT</h1>
        }
        return <h1>GO TO CYBERCORE</h1>
    }

    onChangeIsOk = (value) => () => {
        this.setState({
            isOk: value,
        })
    }

    render() {
        return (
            <div>
                <h3>My Information</h3>
                <span>Tên:</span> {this.fullName}
                <br />
                <span>Age:</span>{this.age}
                <button className="btn btn-success" onClick={this.showName}>Show Name</button>
                <button className="btn btn-success" onClick={this.showNameWithParams('Thái')}>Show Name With Params</button>
                <div className="btn btn-primary" onClick = {this.showNameWithThis}>Show Name With This</div>
                
                <h1>Schedule</h1>
                <button className="btn btn-warning" onClick = {this.onChangeIsOk(true)}>Good</button>
                <button className="btn btn-primary" onClick = {this.onChangeIsOk(false)}>Bad</button>
                {this.decideDestination()}
            </div>
        )
    }
}
