import React, { Component } from 'react'
import Header from '../Header'
import Carousel from '../Carousel'
import Promotion from '../Promotion'
import CardMobile from '../CardMobile'
import CardLaptop from '../CardLapTop'
import '../css/style.css';
export default class ExPromotion extends Component {
    render() {
        return (
            <div className = "bg-dark">
                <Header/>
                <Carousel/>
                <CardMobile/>
                <CardLaptop/>
                <Promotion/>
            </div>
        )
    }
}
