import React, { Component } from 'react'
import Slide_1 from "../img/slide_1.jpg";
import Slide_2 from "../img/slide_2.jpg";
import Slide_3 from "../img/slide_3.jpg";
export default class Carousel extends Component {
    render() {
        return (
            <div>
                {/* BEGIN CAROUSEL */}
                <div id="demo" className="carousel slide" data-ride="carousel">
                        {/* Indicators */}
                        <ul className="carousel-indicators">
                            <li data-target="#demo" data-slide-to={0} className />
                            <li data-target="#demo" data-slide-to={1} className="active" />
                            <li data-target="#demo" data-slide-to={2} className />
                        </ul>
                        {/* The slideshow */}
                        <div className="carousel-inner">
                            <div className="carousel-item active carousel-item-left">
                                <img src={Slide_1} alt="Los Angeles" height={500} />
                            </div>
                            <div className="carousel-item carousel-item-next carousel-item-left">
                                <img src={Slide_2} alt="Chicago" height={500} />
                            </div>
                            <div className="carousel-item">
                                <img src= {Slide_3}  alt="New York" height={500} />
                            </div>
                        </div>
                        {/* Left and right controls */}
                        <a className="carousel-control-prev" href="#demo" data-slide="prev">
                            <span className="carousel-control-prev-icon" />
                        </a>
                        <a className="carousel-control-next" href="#demo" data-slide="next">
                            <span className="carousel-control-next-icon" />
                        </a>
                    </div>
                    {/* END CAROUSEL */}
            </div>
        )
    }
}
