import React from "react";
import Header from "../components/header";
class Home extends React.Component {
    render() {
        return (
            <div>
                <h1>This is Home</h1>
                <Header />
            </div>

        );
    }
}
export default Home;