import React from "react";
import Header from "../components/header";
class Contact extends React.Component{
    render(){
       return(
           <div>
               <h1>This is Contact page</h1>
               <p>Contact to me</p>
               <Header/>
           </div>
       )
    }
}
export default Contact;