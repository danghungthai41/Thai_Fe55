import './App.css';
// import ExPromotion from './DangHungThai_BaiTap_ReactJs/Home';
import ShoppingHome2 from './Second_ShoppingHome';
// import ShoppingHome from './ShoppingCart';

// import DemoDatabinding from './Databinding';
// import ExerciseChangeColorCars from './ExCars';
// import ExMovieList from './ExMovies';
// import Carousel from './ex-2/Carousel';
// import Content from './ex-2/Content';
// import Footer from './ex-2/Footer';
// import Header from './ex-2/Header/index';
// import Index from './ex-1/index';
// import HomeEx2 from './ex-2/Home';



function App() {
  return (
    <div className="App">
      {/* <Index/> */}
      {/* <Header/>
      <Carousel/>
      <Content/>
      <Footer/> */}
      {/* <HomeEx2/> */}
      {/* <DemoDatabinding/> */}
      {/* <ExerciseChangeColorCars /> */}
      {/* <ExMovieList/> */}
      {/* <ExPromotion/> */}
      {/* <ShoppingHome/> */}
      <ShoppingHome2/>
    </div>
  );
}

export default App;
