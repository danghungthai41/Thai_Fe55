var changeContent = ()=>{
    var theNoiDung = document.getElementById('theNoiDung');
        theNoiDung.innerHTML = 'Anh Sang dạy hay hơn!';
}

//Hàm xử lý Tắt Đèn và Bật Đèn
var turnOn = ()=>{
    var theHinhAnh = document.getElementById('theImg');
        theHinhAnh.src = './img/pic_bulbon.gif';
}
var turnOff = function(){
    var theHinhAnh = document.getElementById('theImg');
        theHinhAnh.src = './img/pic_bulboff.gif';
}

// Event onclick
var turnOffLight = document.getElementById('turnOffLight');
    turnOffLight.onclick = turnOff;
var turnOnLight = document.getElementById('turnOnLight');
    turnOnLight.onclick = turnOn;
