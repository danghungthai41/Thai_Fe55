var NhanVien = function(){
    this.maNhanVien = '';
    this.tenNhanVien='';
    this.luongCoBan ='';
    this.chucVu = '';
    this.gioLamTrongThang ='';
    this.heSoChucVu = '';
    this.tinhTongLuong = function(){
        return this.gioLamTrongThang * this.heSoChucVu;
    },
    this.xepLoaiNhanVien = function(){
        if (this.gioLamTrongThang >= 120) {
            return 'Nhân Viên Xuất Sắc';
        } else if (this.gioLamTrongThang >= 100){
            return 'Nhân Viên Giỏi';
        } else if (this.gioLamTrongThang >= 80) {
            return 'Nhân Viên Khá';
        } else if (this.gioLamTrongThang >= 50) {
            return 'Nhân Viên Trung Bình';
        } else {
            return 'Không xác định';
        }
    }
}