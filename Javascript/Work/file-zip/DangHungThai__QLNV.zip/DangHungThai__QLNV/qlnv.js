var getSection = function(id){
    return document.querySelector(id);
}
var createEle = function(tag){
    return document.createElement(tag);
}

getSection('#btnXacNhan').onclick = function(){
    var nv = new NhanVien();
    nv.maNhanVien = getSection('#maNhanVien').value;
    nv.tenNhanVien = getSection('#tenNhanVien').value;
    nv.heSoChucVu = getSection('#chucVu').value;
    
    nv.luongCoBan = getSection('#luongCoBan').value;
    nv.gioLamTrongThang = getSection('#gioLamTrongThang').value;

    var mangChucVu = getSection('#chucVu').options;
    var viTriChucVu = getSection('#chucVu').selectedIndex;
    nv.chucVu = mangChucVu[viTriChucVu].innerHTML;

    var trNhanVien = createEle('tr');
    var tdMaNhanVien = createEle('td');
    var tdTenNhanVien = createEle('td');
    var tdChucVu = createEle('td');
    var tdLuongCoBan = createEle('td');
    var tdTongLuong = createEle('td');
    var tdGioLamTrongThang = createEle('td');
    var tdXepLoai = createEle('td');


    tdMaNhanVien.innerHTML = nv.maNhanVien;
    tdTenNhanVien.innerHTML = nv.tenNhanVien;
    tdChucVu.innerHTML = nv.chucVu;
    tdLuongCoBan.innerHTML = nv.luongCoBan;
    tdTongLuong.innerHTML = nv.tinhTongLuong();
    tdGioLamTrongThang.innerHTML = nv.gioLamTrongThang;
    tdXepLoai.innerHTML = nv.xepLoaiNhanVien();


    //Thêm chức năng xoá
    var tdChucNangXoa = createEle('td');
    var btnChucNang = createEle('button');
    btnChucNang.innerHTML = 'Xoá';
    btnChucNang.className = 'btn btn-danger';

    btnChucNang.onclick = function(){
        trNhanVien.className = 'bg-primary';
        trNhanVien.remove();
    }

    tdChucNangXoa.appendChild(btnChucNang);
    trNhanVien.appendChild(tdMaNhanVien);
    trNhanVien.appendChild(tdTenNhanVien);
    trNhanVien.appendChild(tdChucVu);
    trNhanVien.appendChild(tdLuongCoBan);
    trNhanVien.appendChild(tdTongLuong);
    trNhanVien.appendChild(tdGioLamTrongThang);
    trNhanVien.appendChild(tdXepLoai);
    trNhanVien.appendChild(tdChucNangXoa);

    var tbody = getSection('#addBody')
    tbody.appendChild(trNhanVien);
}