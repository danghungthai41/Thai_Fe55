import './App.css';

import Courses from './components/CourseExer/Courses'
function App() {
  return (
    <div className="App">
      {/* <Control/>
      <Students/> */}
      <Courses/>
    </div>
  );
}

export default App;
