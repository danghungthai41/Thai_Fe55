import React, { Component } from "react";
import { fetchCourseList } from "../../../redux/action/courseList";
import { Container, Grid, Typography } from "@material-ui/core"
import { connect } from "react-redux";
import CourseItem from "../CourseItem";
class Courses extends Component {
    renderCourseList = () => {
        return this.props.courses?.map((item, index)=>{
            return <CourseItem key = {index} course = {item}/>
        })
    }
  render() {
    return (
      <div>
        <Typography
          component="h1"
          variant="h2"
        >
          Danh Sách Khoá Học
        </Typography>
        <Container maxWidth="lg">
          <Grid container spacing={3}>
            {this.renderCourseList()}
          </Grid>
        </Container>
      </div>
    );
  }
  componentDidMount() {
    this.props.dispatch(fetchCourseList);
  }
}
const mapStateToProps = (state) => {
    return {
        courses: state.courseReducer.courses,
    }
}
export default connect(mapStateToProps)(Courses);
