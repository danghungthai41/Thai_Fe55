import React, { Component } from 'react'
import {connect} from "react-redux";

class Students extends Component {
    render() {
        const {age, name} = this.props.studentUpdated;
        return (
            <div>
                <h1>Name: {name}</h1>
                <h1>Age: {age}</h1>
            </div>
        )
    }
  

}


const mapStateToProps = (state) => {
    return {
        studentUpdated: state.studentReducer.student,
    }
}
export default connect(mapStateToProps)(Students);