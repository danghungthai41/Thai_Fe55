import React, { Component } from "react";
import {
  Button,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Typography,
} from "@material-ui/core";
class CourseItem extends Component {
  render() {
    const { hinhAnh, tenKhoaHoc, moTa } = this.props.course;
    return (
        <Card>
          <CardActionArea>
            <CardMedia image={hinhAnh} style ={{width: 300, height: 400}} />
            <CardContent>
              <Typography gutterBottom variant="h5" component="h2">
                {tenKhoaHoc}
              </Typography>
              <Typography variant="body2" color="textSecondary" component="p">
                {moTa}
              </Typography>
            </CardContent>
          </CardActionArea>
          <CardActions>
            <Button size="small" color="primary">
              Detail
            </Button>
          </CardActions>
        </Card>
    );
  }
}

export default CourseItem;
