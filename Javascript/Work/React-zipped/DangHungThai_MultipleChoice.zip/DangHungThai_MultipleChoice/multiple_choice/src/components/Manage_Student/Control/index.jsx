import React, { Component } from "react";
import { connect } from "react-redux";
import { createAction } from "../../redux/action";
import { CHANGE_AGE } from "../../redux/constants/changeAge";
// import Students from "../Students";
class Control extends Component {
  increaseAge = () => {
    let { age } = this.props.student;
    age++;
    this.props.dispatch(createAction(CHANGE_AGE, age));
  };

  render() {
    return (
      <div>
        <button onClick={this.increaseAge}>Age++</button>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    student: state.studentReducer.student,
  };
};
export default connect(mapStateToProps)(Control);
