import { FETCH_COURSE_LIST } from "../constants/changeAge";

let initialState = {
    courses : [],
};
const reducer = (state = initialState, {type, payload}) => {
    switch (type) {
       case FETCH_COURSE_LIST:
           state.courses = payload;
           return {...state};
        default:
            return state;
    }
}
export default reducer;
