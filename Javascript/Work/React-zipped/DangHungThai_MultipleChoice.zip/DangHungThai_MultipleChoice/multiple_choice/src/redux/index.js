import {createStore, combineReducers, applyMiddleware} from "redux";
import studentReducer from "./reducers/student";
import courseReducer from "./reducers/course";
import thunk from "redux-thunk";

const rootReducer = combineReducers({
    studentReducer,
    courseReducer,
})

const store = createStore(rootReducer,applyMiddleware(thunk))
export default store;