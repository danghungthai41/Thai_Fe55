import { createAction } from ".";
import { FETCH_COURSE_LIST } from "../constants/changeAge";
import axios from "axios";
export const fetchCourseList = (dispatch) => {
  axios({
    url:
      "https://elearning0706.cybersoft.edu.vn/api/QuanLyKhoaHoc/LayDanhSachKhoaHoc?MaNhom=GP01",
    method: "GET",
  })
    .then((result) => {
        console.log(result.data)
        dispatch(createAction(FETCH_COURSE_LIST, result.data))
    })
    .catch((err) => { 
        console.log(err)
    });
};
