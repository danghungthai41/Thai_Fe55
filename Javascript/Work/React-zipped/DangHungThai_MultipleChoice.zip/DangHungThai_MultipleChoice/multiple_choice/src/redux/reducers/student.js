import { CHANGE_AGE } from "../constants/changeAge";
 
let initialState = {
    student: {
        name: "Thái",
        age: 1,
    }
}
const reducer = (state = initialState, {type, payload}) => {
    switch (type) {
       case CHANGE_AGE:
           let stuUpdate = {...state.student, age:payload}
            state.student = stuUpdate;
        return {...state};
        default:
            return state;
    }
}
export default reducer;